export interface Book{
    id?:string;
    name?:string;
    img?:string;
    price?:string;
  }